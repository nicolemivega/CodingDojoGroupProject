// const userRegistrationControllers = require('../controllers/userRegistrationControllers');

// module.exports = app => {
//     app.post('/api/register',userRegistrationControllers.register);
//     app.get('/api/register',userRegistrationControllers.findAll);
//     app.get('/api/register/:id',userRegistrationControllers.findOneUser);
//     app.post('/api/register',userRegistrationControllers.createUser);
//     app.put('/api/register/:id',userRegistrationControllers.updateUser);   
//     app.delete("/api/register/:id",userRegistrationControllers.delete);

// }